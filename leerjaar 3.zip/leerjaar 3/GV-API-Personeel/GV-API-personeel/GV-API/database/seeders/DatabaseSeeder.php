<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {


        \App\Models\User::factory(10)->create();

        DB::table('users')->insert([
            'firstName' => 'Ajda',
            'lastName' => ' Özmen',
            'birthdate' => fake()->dateTimeBetween('-60 years', '-18 years')->format('Y-m-d'),
            'email' => 'AJOZ@gmail.com',
            'email_verified_at' => now(),
            'password' => '$2a$11$lsUqIaxw7SCeA44wttsveOrPx/s46jgCC2Ea4a3V/ogHXs11p8Nn.', // password
            'remember_token' => Str::random(10),
            'address' => fake()->streetAddress(),
            'city' => fake()->city(),
            'postalCode' => fake()->postcode(),
            'function' => fake()->jobTitle()
        ]);
        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
