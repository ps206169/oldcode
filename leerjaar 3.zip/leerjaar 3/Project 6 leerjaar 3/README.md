14/02/2023: Leeg project opgezet en gepusht naar de main branch.
            Zit nu ook een statisch inlogsysteem in met fouten afhandeling voor lege veld(en) en onjuiste gegevens.