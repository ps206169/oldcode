﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Beheerdersysteem.Models;
using Newtonsoft.Json;
using MySqlX.XDevAPI;
using System.Windows.Markup;
using System.Net.Http.Json;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json.Linq;

namespace Beheerdersysteem
{
    /// <summary>
    /// Interaction logic for AddtoCartScreen.xaml
    /// </summary>
    public partial class AddtoCartScreen : Window
    {
        private RadioButton selectedRadioButton;

        EmployeeDB DB = new EmployeeDB();

        public AddtoCartScreen(Product product)
        {
            InitializeComponent();
            DataContext = product;

        }

        private void RbOther_Checked(object sender, RoutedEventArgs e)
        {
            TbOther.Visibility = Visibility.Visible;
        }

        private void RbOther_Unchecked(object sender, RoutedEventArgs e)
        {
            TbOther.Visibility = Visibility.Collapsed;
        }




        private async void BtAdd_Click(object sender, RoutedEventArgs e)
        {


            int quantity;
            int productId = ((Product)DataContext).Id;


            switch (true)
            {
                case bool b when Rb1.IsChecked == b:
                    quantity = 1;
                    break;
                case bool b when Rb5.IsChecked == b:
                    quantity = 5;
                    break;
                case bool b when Rb10.IsChecked == b:
                    quantity = 10;
                    break;
                case bool b when Rb20.IsChecked == b:
                    quantity = 20;
                    break;
                case bool b when Rb25.IsChecked == b:
                    quantity = 25;
                    break;
                case bool b when Rb50.IsChecked == b:
                    quantity = 50;
                    break;
                case bool b when RbOther.IsChecked == b:
                    if (int.TryParse(TbOther.Text, out quantity))
                    {
                        // Quantity is valid, do something with it
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid quantity.");
                        return;
                    }
                    break;
                default:
                    MessageBox.Show("Please select a quantity.");

                    return;
            }
   

            var orderItem = new  {

                order_id = TbOrderId.Text,
                product_id = productId,
                quantity = quantity
        };

            // Convert the order item object to a JSON string
            var orderItemJson = JsonConvert.SerializeObject(orderItem);
            var content = new StringContent(orderItemJson, Encoding.UTF8, "application/json");

            string token = "61|ssmAFLTxdE1vxiXQQmOEbZc6GB7ZpWF24XB5jAo7";
            // Create a new HttpClient object
            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.PostAsync("https://kuin.summaict.nl/api/orderItem", content);
                if (!response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Failed to get data from the API");//Als de communicatie met de api faalt wordt deze messagebox zichtbaar
                    return;
                }

                var responseContent = await response.Content.ReadAsStringAsync();
                var orderItemResponse = JsonConvert.DeserializeObject<OrderItem>(responseContent);


                // Check if the order_id property is set
                if (orderItemResponse.order_id != null)
                {
                    MessageBox.Show("Order item created successfully with order_id: " + orderItemResponse.order_id);

                }
                else
                {
                    MessageBox.Show("Error creating order item. Please try again later.");
                }

                //orderItem.product_id, orderItem.quantity

                Stock stock = new Stock();
                stock.Id = productId;
                Stock test = DB.Checkstock(stock);

                if (stock != null)
                {
                    int CurrentStock = test.Amount + quantity;
                    DB.UpdateStock(productId, CurrentStock);
                }

                else
                {
                    MessageBox.Show("Er is iets fout gegaan met het updaten van de voorraad.");
                }




            }

            this.Close();
        }

    }
}
