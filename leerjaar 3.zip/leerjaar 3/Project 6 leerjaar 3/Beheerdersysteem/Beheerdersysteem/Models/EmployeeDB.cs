﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using BCrypt.Net;


namespace Beheerdersysteem.Models
{
    public class EmployeeDB
    {
        //dit is letterlijk allemaal tijdelijk totdat we de api live hebben staan
        //public MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Employee"]
        //          .ConnectionString);
        private readonly MySqlConnection conn;

        public EmployeeDB()
        {
            conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Employee"].ConnectionString);
        }

        public EmployeeDB(MySqlConnection connection)
        {
            conn = connection;
        }
        //private readonly MySqlConnection _connection;

        //public EmployeeDB(MySqlConnection connection)
        //{
        //    _connection = connection;
        //}
        #region Get Employee List
        public List<EmployeeData> GetEmployeeData()
        {
            List<EmployeeData> employees = new List<EmployeeData>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT u.id, u.email, u.FirstName, u.LastName, p.PostalCode, u.PostalCodeID, p.id, p.City, p.StreetName, u.HouseNumber
                      FROM users u
                      JOIN postal_codes p ON p.id = u.PostalCodeID
                      JOIN userroles ur ON ur.UserID = u.id
                      WHERE ur.RoleID = 1";
                    
                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    EmployeeData employeeData = new EmployeeData();
                    employeeData.Id = (int)row["id"];
                    employeeData.FirstName = (string)row["FirstName"];
                    employeeData.LastName = (string)row["LastName"];
                    employeeData.Email = (string)row["Email"];
                    employeeData.City = (string)row["City"];
                    employeeData.PostalCode = (string)row["PostalCode"];
                    employeeData.HouseNumber = (int)row["HouseNumber"];
                    employeeData.City = (string)row["City"];
                    employeeData.StreetName = (string)row["StreetName"];
                    employees.Add(employeeData);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return employees;
        }
        #endregion
        #region Login Function
        public EmployeeData ReadRole(EmployeeData employee)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)   
                    conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = @" 
                        SELECT u.id, u.email, u.password 
                        FROM users u
                        WHERE u.email = @email";
                sql.Parameters.AddWithValue("@email", employee.Email);

                MySqlDataReader reader = sql.ExecuteReader();
                while (reader.Read())
                {

                    if (BCrypt.Net.BCrypt.Verify(employee.Password, (string)reader["password"]))
                    {
                        EmployeeData login = new EmployeeData();
                        //login.ID = (int)reader["id"];
                        login.Email = (string)reader["email"];
                        login.Password = (string)reader["password"];
                        return login;
                    }
                }


            }


            catch (Exception ex)
            {
                // iets doen want fout
                return null;
            }
            finally
            {
                conn.Close();
            }
            return null;
        }
        #endregion
        #region Update Function
        public bool UpdateUser(int id, string email, string firstName, string lastName, string city, string postalCode, int houseNumber, string streetName)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE users u " +
                                  "SET u.Email = @email, " +
                                  "u.FirstName = @firstName, " +
                                  "u.LastName = @lastName, " +
                                  "u.HouseNumber = @houseNumber " +
                                  "WHERE u.id = @id; " +
                                  "UPDATE postal_codes p " +
                                  "SET p.City = @city, " +
                                  "p.PostalCode = @postalCode, " +
                                  "p.StreetName = @streetName " +
                                  "WHERE p.id = (SELECT PostalCodeID FROM users WHERE id = @id);";

                //Might have to change everything in front of the = signs back to non capitalized letters
                sql.Parameters.AddWithValue("@id", id);
                sql.Parameters.AddWithValue("@email", email);
                sql.Parameters.AddWithValue("@FirstName", firstName);
                sql.Parameters.AddWithValue("@LastName", lastName);
                sql.Parameters.AddWithValue("@City", city);
                sql.Parameters.AddWithValue("@PostalCode", postalCode);
                sql.Parameters.AddWithValue("@HouseNumber", houseNumber);
                sql.Parameters.AddWithValue("@StreetName", streetName);

                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }
        #endregion
        #region Delete function
        public bool DeleteEmployee(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM users WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
        #region Create Function
        public bool InsertUser(string FirstName, string LastName, string Email, string City, string PostalCode, int HouseNumber, string StreetName, string Password, DateTime Birthday)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    "INSERT INTO postal_codes(City, PostalCode, StreetName) VALUES(@City, @PostalCode, @StreetName);" +
                    "SET @PostalCodeId = LAST_INSERT_ID();" +
                    "INSERT INTO users(FirstName, LastName, email, PostalCodeID, HouseNumber, password, Birthday)" +
                    "VALUES(@FirstName, @LastName, @Email, @PostalCodeId, @HouseNumber, @password, @Birthday)";

                sql.Parameters.AddWithValue("@FirstName", FirstName);
                sql.Parameters.AddWithValue("@LastName", LastName);
                sql.Parameters.AddWithValue("@email", Email);
                sql.Parameters.AddWithValue("@StreetName", StreetName);
                sql.Parameters.AddWithValue("@City", City);
                sql.Parameters.AddWithValue("@PostalCode", PostalCode);
                sql.Parameters.AddWithValue("@HouseNumber", HouseNumber);
                sql.Parameters.AddWithValue("@StreetName", StreetName);
                sql.Parameters.AddWithValue("@password", HashPassword(Password));
                sql.Parameters.AddWithValue("@Birthday", Birthday);

                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        private string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }
        #endregion
        #region call stock
        public Stock Checkstock(Stock stock)
        {
          
            try
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = @" 
                        SELECT p.amount FROM products p WHERE p.id = @Id";
                sql.Parameters.AddWithValue("@Id", stock.Id);

                MySqlDataReader reader = sql.ExecuteReader();
                while (reader.Read())
                {
                    Stock stockcheck = new Stock();
                        stockcheck.Amount = (int)reader["amount"];
                        return stockcheck;
                }
            }
            catch (Exception ex)
            {
                // iets doen want fout
                return stock;
            }
            finally
            {
                conn.Close();
            }
            return stock;
        }
        #endregion
        #region update stock
        public bool UpdateStock(int productId, int CurrentStock)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE `products` SET `amount` =@amount WHERE id = @Id;";
                sql.Parameters.AddWithValue("@Id", productId);
                sql.Parameters.AddWithValue("@amount", CurrentStock);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }

        #endregion
    }
}
