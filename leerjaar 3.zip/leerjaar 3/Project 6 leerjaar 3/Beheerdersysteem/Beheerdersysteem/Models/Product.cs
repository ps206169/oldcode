﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel; 
using System.Runtime.CompilerServices;
using System.Globalization;
using System.Windows;

namespace Beheerdersysteem.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public int Height_cm { get; set; }
        public int Width_cm { get; set; }
        public int Depth_cm { get; set; }
        public int Weight_gr { get; set; }
        public string Color { get; set; }
        public static string Phonenumber { get;  } = "06-91204657";
    }

}
