﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerdersysteem.Models
{
    public class Stock
    {
        public long Id { get; set; }
        public int Amount { get; set; }
        
    }
}
