﻿using Beheerdersysteem.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerdersysteem
{
    /// <summary>
    /// Interaction logic for EmployeePage.xaml
    /// </summary>
    public partial class EmployeePage : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<EmployeeData> employeeDataLst = new ObservableCollection<EmployeeData>();

        public ObservableCollection<EmployeeData> EmployeeDataList
        {
            get { return employeeDataLst; }
            set { employeeDataLst = value; }
        }

        private EmployeeData selectedEmployee;
        public EmployeeData SelectedEmployee
        {
            get { return selectedEmployee; }
            set { selectedEmployee = value; OnPropertyChanged(); }
        }

        EmployeeDB DB = new EmployeeDB();

        public EmployeePage()
        {
            loadEmployeeLst();
            InitializeComponent();
            DataContext = this;
        }
        public void loadEmployeeLst()
        {
            try
            {
                List<EmployeeData> lstEmployeeData = DB.GetEmployeeData();

                if (lstEmployeeData == null || lstEmployeeData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                EmployeeDataList.Clear();

                foreach (EmployeeData employeeData in lstEmployeeData)
                {
                    Debug.WriteLine("Adding employee: " + employeeData.FirstName + " " + employeeData.LastName);
                    EmployeeDataList.Add(employeeData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                EmployeeDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (!DB.DeleteEmployee((int)selectedEmployee.Id))
            {
                MessageBox.Show("Er is een fout bij het verwijderen");
                return;
            };
            loadEmployeeLst();


        }

        private void OnCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                // Krijg de informatie van de datagrid cell
                var editedCell = e.EditingElement as TextBox;
                var editedContent = editedCell.Text;

                // krijg de overig informatie van de cell
                var editedEmployee = e.Row.DataContext as EmployeeData;

                // je krijgt het ID van je rij, ivm dat je de ID niet aanpast 
                var editedEmployeeID = ((EmployeeData)e.Row.Item).Id;

                var editedColumn = e.Column.Header.ToString();
                //allemaal tijdelijk zodat ik kan zien of de informatie wordt opgeslagen
                switch (editedColumn)
                {
                    case "Voornaam":
                        editedEmployee.FirstName = editedContent;
                   
                        break;
                    case "Achternaam":
                        editedEmployee.LastName = editedContent;
                      
                        break;
                    case "Email":
                        editedEmployee.Email = editedContent;
                        
                        break;
                    case "Stad":
                        editedEmployee.City = editedContent;
                        
                        break;
                    case "Postcode":
                        editedEmployee.PostalCode = editedContent;

                        break;
                    case "HuisNummer":
                        int houseNumber;
                        if (int.TryParse(editedContent, out houseNumber))
                        {
                            editedEmployee.HouseNumber = houseNumber;
                        }

                        break;
                    case "StraatNaam":
                        editedEmployee.StreetName = editedContent;

                        break;
                    default:
                        MessageBox.Show("Je Hebt niks aangepast.");
                        break;
                }
                // Update the corresponding row in the database
                DB.UpdateUser(editedEmployeeID,
                              editedEmployee.Email,
                              editedEmployee.FirstName,
                             editedEmployee.LastName,
                             editedEmployee.PostalCode,
                             editedEmployee.City,
                             editedEmployee.HouseNumber,
                             editedEmployee.StreetName);
            }
        
        }

        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            Add_Menu add_menu = new Add_Menu();
            add_menu.Show();
        }
    }

}
