﻿using Beheerdersysteem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerdersysteem
{
    /// <summary>
    /// Interaction logic for ProductDetails.xaml
    /// </summary>
    public partial class ProductDetails : Page
    {

        public ProductDetails(Product product)
        {
            InitializeComponent();
            DataContext= product;
        }

        private void BtGoBack_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Collapsed;


        }
        private void BtAddToCart_Click(object sender, RoutedEventArgs e)
        {
            AddtoCartScreen addtoCartScreen = new AddtoCartScreen((Product)DataContext);
            addtoCartScreen.Show();

        }
    }
}
