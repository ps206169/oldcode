﻿using Beheerdersysteem.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerdersysteem
{
    /// <summary>
    /// Interaction logic for Add_Menu.xaml
    /// </summary>
    public partial class Add_Menu : Window
    {
     

        public Add_Menu()
        {
            InitializeComponent();

        }
        EmployeeDB DB = new EmployeeDB();
        private void BtAdd_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrEmpty(TbFirstName.Text)) 
                || (string.IsNullOrEmpty(TbLastName.Text)) 
                || (string.IsNullOrEmpty(TbEmail.Text)) 
                || (string.IsNullOrEmpty(TbStreetName.Text))
                || (string.IsNullOrEmpty(TbCity.Text))
                || (string.IsNullOrEmpty(TbPostalCode.Text)))
            {
                MessageBox.Show("Graag gegevens invoeren");
            }
            else
            {
                try
                {
                    //if (!DB.InsertUser(TbFirstName.Text, TbLastName.Text, TbStreetName.Text, TbEmail.Text, TbCity.Text, TbPostalCode.Text))
                    //{
                    //    MessageBox.Show("Er is een fout bij het toevoegen");
                    //    return;
                    //}
                    //this.Close();
                }
                catch
                {
                    MessageBox.Show("Graag getal invoeren bij prijs");

                }

            }
        }
    }
}
