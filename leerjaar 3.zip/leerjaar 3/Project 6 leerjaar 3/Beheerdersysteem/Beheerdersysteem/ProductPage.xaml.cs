﻿using Beheerdersysteem.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel; 
using System.Runtime.CompilerServices;
using Mysqlx.Notice;
using Google.Protobuf.WellKnownTypes;
using System.Net.Http.Headers;
using System.Net.Http;

namespace Beheerdersysteem
{

    /// <summary>
    /// Interaction logic for ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<Product> productList = new ObservableCollection<Product>(); //Een nette collectie van de doorgestuurde data die door de Product class wordt gehaald en de variable die ik daarin heb staan eruit haalt.

        private ObservableCollection<Product> filteredList = new ObservableCollection<Product>();
        private int currentPage = 1; //Eerste pagina
        private int itemsPerPage = 20; //Limiet van producten op 1 pagina
      

        public ObservableCollection<Product> ProductList
        {
            get
            {
                int startIndex = (currentPage - 1) * itemsPerPage;
                return new ObservableCollection<Product>(productList.Skip(startIndex).Take(itemsPerPage));
                // berekent op welke pagina je bent en welke producten daar toebehoren.
            }
            
            set { productList = value; }
        }
        private Product selectedProduct;

        public Product SelectedProduct
        {
            get { return selectedProduct; }
            set { selectedProduct = value; OnPropertyChanged(); }
        }


        public ProductPage()
        {
            InitializeComponent();
            LoadData();
            

            DataContext = this;


        }

        private async void LoadData()
        {
            string token = "61|ssmAFLTxdE1vxiXQQmOEbZc6GB7ZpWF24XB5jAo7";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token); //De token wordt aangeroepen als Bearer token
                var response = await client.GetAsync("https://kuin.summaict.nl/api/product");//De token wordt gebruikt om verbinding te maken met de api
                if (!response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Failed to get data from the API");//ALs de communicatie met de api faalt wordt deze messagebox zichtbaar
                    return;
                }
                var data = await response.Content.ReadAsStringAsync();
                FillList(data);

            }

        }
        public void FillList(string data)
        {
            var productData = JsonConvert.DeserializeObject<List<Product>>(data);
            foreach (var item in productData)
            {
                productList.Add(item); //gaat door alle items van de API data en zet ze in de productData die de data visueel laat zien.
            }
            
            OnPropertyChanged(nameof(ProductList));
            DataContext = this;
            
        }

        private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {

                currentPage--;
                OnPropertyChanged(nameof(ProductList));


            }
        }


        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage < (productList.Count + itemsPerPage - 1) / itemsPerPage)
            {
                currentPage++;
                OnPropertyChanged(nameof(productList));
            }
        }

        private void ProductDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selectedProduct = ProductDataGrid.SelectedItem as Product; //Vanwege dat er op de detail pagina meerd informatie wordt aangeroepen dan op deze pagina moet er meer informatie van het product uit de API opgehaald worden.


            if (selectedProduct != null)
            {
                ProductDetailsFrame.Content = new ProductDetails(selectedProduct); //Het geselecteerde product wordt doorgestuurd naar de detail pagina.
                ProductDetailsFrame.Visibility = Visibility.Visible;
 
            }

        }


        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = tbSearch.Text;

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                productList.Clear();
                ProductList.Clear();
                LoadData();
                ProductDataGrid.Items.Refresh();
            }
            else
            {

                // Perform the search
                ObservableCollection<Product> searchResults = Search(searchTerm);

                // Update the ProductList with the search results

                filteredList.Clear();
                ProductList.Clear();
                foreach (var result in searchResults)
                {
                    filteredList.Add(result);
                }
                ProductList = filteredList;


                currentPage = 1;
                OnPropertyChanged(nameof(ProductList));
                ProductDataGrid.Items.Refresh();
            }

        }

        public ObservableCollection<Product> Search(string searchTerm)
        {
            ObservableCollection<Product> searchResults = new ObservableCollection<Product>();

            // Perform the search using LINQ
            var results = productList.Where(product => product.Name.Contains(searchTerm));

            // Add the matching results to the searchResults collection
            foreach (var result in results)
            {
                searchResults.Add(result);
            }

            return searchResults;
        }

    }
}
