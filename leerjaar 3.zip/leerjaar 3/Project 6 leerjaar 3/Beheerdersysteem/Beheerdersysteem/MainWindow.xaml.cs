﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Beheerdersysteem.Models;
using Newtonsoft.Json;
using MySqlX.XDevAPI;
using Newtonsoft.Json.Linq;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Markup;

namespace Beheerdersysteem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        private EmployeeData employee = new EmployeeData();

        public EmployeeData Employee
        {
            get { return employee; }
            set { employee = value; OnPropertyChanged(); }
        }

        EmployeeDB DB = new EmployeeDB();
        public MainWindow()
        {
            InitializeComponent();
            Tab.Visibility = Visibility.Hidden;
            DataContext = this;



        }

        private async void BtLogin_Click(object sender, RoutedEventArgs e)
        {
            Employee.Email = TbUser.Text;
            Employee.Password = PbPassword.Password;

            EmployeeData login = DB.ReadRole(Employee);
                switch (login)
                {
                    case null:
                        MessageBox.Show("Voer een wachtwoord in.");
                        PbPassword.Clear();
                        break;

                    default:
                    TbUser.Text = " ";
                    PbPassword.Password = " ";
                        Tab.Visibility = Visibility.Visible;
                        btLogout.Visibility = Visibility.Visible;
                        Logo.Visibility = Visibility.Visible;
                        Inlog_Grid.Visibility = Visibility.Hidden;  

                    break;
                }
            

        }

        //    string email = TbUser.Text;
        //    string password = PbPassword.Password;


        //    string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

        //    // Create an HTTP client to call the API
        //    using (HttpClient client = new HttpClient())
        //    {
        //        // Set the API endpoint URL
        //        string apiUrl = "http://127.0.0.1:8000/login";

        //        // Create a dictionary to hold the email and password
        //        Dictionary<string, string> loginData = new Dictionary<string, string>
        //{
        //    { "email", email },
        //    { "password", password  }
        //};

        //        // Convert the login data to JSON
        //        string jsonData = JsonConvert.SerializeObject(loginData);

        //        // Create a request content with the JSON data
        //        HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

        //        // Send a POST request to the API endpoint with the login data
        //        HttpResponseMessage response = await client.PostAsync(apiUrl, content);

        //        // Check if the response was successful
        //        if (response.IsSuccessStatusCode)
        //        {
        //            // Parse the response content as JSON
        //            string responseJson = await response.Content.ReadAsStringAsync();
        //            JObject responseObject = JObject.Parse(responseJson);

        //            // Check if the login was successful
        //            if ((bool)responseObject["success"])
        //            {
        //                MessageBox.Show("Login successful!");
        //                //temporary
        //                PbPassword.Clear();
        //                TbUser.Clear();
        //                Navigation_Grid.Visibility = Visibility.Visible;
        //                Inlog_Grid.Visibility = Visibility.Hidden;
        //            }
        //            else
        //            {
        //                // Display an error message to the user
        //                MessageBox.Show((string)responseObject["message"], "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
        //                PbPassword.Clear();
        //                TbUser.Clear();
        //            }
        //        }
        //        else
        //        {
        //            // Display an error message to the user
        //            MessageBox.Show("An error occurred while logging in. Please try again later.", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
        //            PbPassword.Clear();
        //            TbUser.Clear();
        //        }
        //}
        private async void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabControl tabControl = sender as TabControl;
            TabItem selectedTab = tabControl.SelectedItem as TabItem;

            if (selectedTab.Header.ToString() == "Medewerkers")
            {
                if (UserFrame.Content == null)
                {
                        UserFrame.NavigationService.Navigate(new EmployeePage());

                }
            }
            else if (selectedTab.Header.ToString() == "Producten")
            {
                if (ProductFrame.Content == null)
                {
                    ProductFrame.NavigationService.Navigate(new ProductPage());
                }
            }
        }

        private void btLogout_Click(object sender, RoutedEventArgs e)
        {
            PbPassword.Clear();
            TbUser.Clear();
            Tab.Visibility = Visibility.Collapsed;
            btLogout.Visibility = Visibility.Collapsed;
            Logo.Visibility = Visibility.Collapsed;
            Inlog_Grid.Visibility = Visibility.Visible;

        }
    }
}
