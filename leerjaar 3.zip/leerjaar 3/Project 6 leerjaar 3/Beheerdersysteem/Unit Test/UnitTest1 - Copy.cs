using NUnit.Framework;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;
using Beheerdersysteem.Models;

[TestFixture]
public class EmployeesRepositoryTests
{
    private string connectionString = "server=localhost;database=project6_database;uid=root;pwd=;";

    [Test]
    public void GetEmployees_ReturnsListOfEmployees()
    {
        // Arrange
        List<EmployeeData> expectedEmployees = new List<EmployeeData>
        {
            new EmployeeData { Id = 1, FirstName = "John", LastName = "Doe" },
            new EmployeeData { Id = 2, FirstName = "Jane", LastName = "Smith" },
            // Add more expected employees as per your test scenario
        };

        // Act
        List<EmployeeData> actualEmployees;
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            connection.Open();

            // Assuming you have a method in your EmployeesRepository class called GetEmployees that retrieves the employees from the database
            EmployeeDB employeeDB = new EmployeeDB(connection);
            actualEmployees = employeeDB.GetEmployeeData();
        }

        // Assert
        Assert.AreEqual(expectedEmployees.Count, actualEmployees.Count);
        for (int i = 0; i < expectedEmployees.Count; i++)
        {
            Assert.AreEqual(expectedEmployees[i].Id, actualEmployees[i].Id);
            Assert.AreEqual(expectedEmployees[i].FirstName, actualEmployees[i].FirstName);
            Assert.AreEqual(expectedEmployees[i].LastName, actualEmployees[i].LastName);
            Assert.AreEqual(expectedEmployees[i].Email, actualEmployees[i].Email);
            Assert.AreEqual(expectedEmployees[i].Password, actualEmployees[i].Password);
            Assert.AreEqual(expectedEmployees[i].City, actualEmployees[i].City);
            Assert.AreEqual(expectedEmployees[i].PostalCodeID, actualEmployees[i].PostalCodeID);
            Assert.AreEqual(expectedEmployees[i].StreetName, actualEmployees[i].StreetName);
            Assert.AreEqual(expectedEmployees[i].PostalCode, actualEmployees[i].PostalCode);
            Assert.AreEqual(expectedEmployees[i].HouseNumber, actualEmployees[i].HouseNumber);
            // Add more assertions as per your test scenario
        }
    }
}

public class EmployeeData
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public string City { get; set; }
    public int PostalCodeID { get; set; }
    public string StreetName { get; set; }
    public string PostalCode { get; set; }
    public int HouseNumber { get; set; }
}
