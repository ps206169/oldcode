using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http.Headers;
using System.Net.Http;

namespace Unit_Test
{
    [TestClass]
    public class UnitTest
    {


        [TestMethod]
        public void TestMethod1()
        {

        }

        //[TestMethod]
        //public async Task TestLoadData()
        //{
        //    string token = "61|ssmAFLTxdE1vxiXQQmOEbZc6GB7ZpWF24XB5jAo7";

        //    using (var client = new HttpClient())
        //    {
        //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        //        var response = await client.GetAsync("https://kuin.summaict.nl/api/product");


        //        if (!response.IsSuccessStatusCode)
        //        {
        //            Assert.Fail("Failed to get data from the API");
        //            return;
        //        }

        //        var data = await response.Content.ReadAsStringAsync();
        //        Assert.IsNotNull(data);
        //        // Process the data as needed
        //    }

        //    // Assert your test conditions
        //    Assert.IsTrue(true);
        //}

    }
}