﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace TTS_Timo_Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer myTimer = new DispatcherTimer();
        DispatcherTimer movingTimer = new DispatcherTimer();
        double dEndpoint = 0;
        private string _Naam = null;
        private string _HV = null;
        public MainWindow()
        {
            InitializeComponent();
            myTimer.Interval = new TimeSpan(0, 0, 0, 1);
            myTimer.Tick += myTimer_Tick;
            myTimer.Start();

            movingTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
            movingTimer.Tick += movingTimer_Tick;
            dEndpoint = this.Width - rEndGame.Width - tbWord.Width;
        }
        private void myTimer_Tick(object sender, EventArgs e)
        {
            int seconds = int.Parse(tbTimer.Text);
            seconds++;
            tbTimer.Text = seconds.ToString();


        }

        private void movingTimer_Tick(object sender, EventArgs e)
        {
            tbWord.Margin = new Thickness(tbWord.Margin.Left + 5, tbWord.Margin.Top, 0, 0);

            if (tbWord.Margin.Left >= dEndpoint)
            {
                myTimer.Stop();
                movingTimer.Stop();
                SetInitialPosition();
                MessageBox.Show("Te laat... :(");
                
            }
        }
        private void tbNaam_GotFocus(object sender, RoutedEventArgs e)
        {
            tbNaam.Text = " ";
        }

        private void tbHV_GotFocus(object sender, RoutedEventArgs e)
        {
            tbHoudenVan.Text = " ";
        }



        private void SetInitialPosition()
        {
            tbWord.Margin = new Thickness(0, tbWord.Margin.Top, 0, 0);
            tbWord.Text = string.Empty;
        }

        private void cbArtiesten_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string Artiest = "";
            try
            {
                ComboBoxItem SelectedArtiest = cbArtiesten.SelectedItem as ComboBoxItem;
                Artiest = SelectedArtiest.Content.ToString();
            }
            catch { }
            switch (Artiest)
            {
                case "Pink":
                    tbTimer.Text = "0";
                    SetInitialPosition();
                    movingTimer.Start();
                    myTimer.Start();
                    break;
                case "Ed Sheeran":
                    tbTimer.Text = "0";
                    SetInitialPosition();
                    movingTimer.Start();
                    myTimer.Start();
                    break;
                case "Nickelback":
                    tbTimer.Text = "0";
                    SetInitialPosition();
                    movingTimer.Start();
                    myTimer.Start();
                    break;
                case "Greenday":
                    tbTimer.Text = "0";
                    SetInitialPosition();
                    movingTimer.Start();
                    myTimer.Start();
                    break;
                case "Guns N' Roses":
                    tbTimer.Text = "0";
                    SetInitialPosition();
                    movingTimer.Start();
                    myTimer.Start();
                    break;
            }
        }

        private void tbWord_TextChanged(object sender, TextChangedEventArgs e)
        {
            _Naam = tbNaam.Text;
            ComboBoxItem SelectedArtiest = cbArtiesten.SelectedItem as ComboBoxItem;
            string Artiest = SelectedArtiest.Content.ToString();
            if (tbWord != null && cbArtiesten != null)
            {
                if (tbWord.Text.Length == 0)
                { return; }
                if (tbWord.Text.ToUpper() == (SelectedArtiest.Content.ToString()).ToUpper())
                {   myTimer.Stop();
                    movingTimer.Stop();
                    MessageBox.Show("Goed Getypt");
                    MessageBox.Show("Jij bent " + _Naam + " en je houdt van " + Artiest);
                }
            }
        }
    }
}




