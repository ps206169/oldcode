﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace TimerOpdracht
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer _myTimer = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            configurateMyTimer();
        }
        private void btStart_Click(object sender, RoutedEventArgs e)
        {
            if (_myTimer.IsEnabled)
            {
                _myTimer.Stop();
                btStart.Content = "Start";
                return;

            }
            else
            {
                _myTimer.Start();
                btStart.Content = "Stop";
            }

        }
        private void configurateMyTimer()
        {
            _myTimer.Interval = TimeSpan.FromSeconds(1);
            _myTimer.Tick += _myTimer_Tick;
        }



        private void _myTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                tbTimer.Text = (Int32.Parse(tbTimer.Text) + 1).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Error -> Not a valid number in the textblock");
            }
        }

        private void btResetTimer_Click(object sender, RoutedEventArgs e)
        {
            tbTimer.Text = "0";
        }

        private void btSecondWindow_Click(object sender, RoutedEventArgs e)
        {
            Window1 win1 = new Window1();
            win1.Show();

        }
    }
}
