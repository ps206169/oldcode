﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Wpf_prg2_timers
{
    /// <summary>
    /// Interaction logic for Bartender.xaml
    /// </summary>
    public partial class Bartender : Window
    {

        //key downs makes a move left/right, automatically up/down
        //spawns a glass of beer at top        
        //game time in seconds

       

        public Bartender()
        {
            InitializeComponent();
            
        }
        public Bartender(string sNamePlayer)
        {
            InitializeComponent();
            
        }

        private void InitialiseTimers()
        {
           
        }

        private void TmrMove_Tick(object sender, EventArgs e)
        {
            
        }

        private void TmrSpawnBeer_Tick(object sender, EventArgs e)
        {
            NewBeer();
        }
        private void TmrEndGame_Tick(object sender, EventArgs e)
        {

        }

        private void NewBeer()
        {
            //creates new Image 
            Image img = new Image();
            img.Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/Resources/beer.png"));
            img.Width = 50;
            img.Height = 60;

            //spawns somewhere at top window. Random x-position
           
        }

        private Rect GetRectOfImage(Image img)
        {
            Point pRectLocation = img.TranslatePoint(new Point(0, 0), grGameGrid);
            return new Rect(pRectLocation.X, pRectLocation.Y, img.ActualWidth, img.ActualHeight);
        }
    }
   

}
