Opdracht 8.1 start met Window Countdown.xaml.
Hier krijgt gebruiker 10 seconden om zijn naam te typen. Lukt dit niet dan volgt een melding
Typt hij en klikt hij binnen de tijd op OK dan volgt het scherm WordRocket.xaml.

opdracht 8.2 is Bartender.xaml. Hierin vallen glazen bier naar beneden die je met de A-toets en D-toets kan opvangen. Gevangen glazen leveren punten op, gemiste glazen kosten punten.