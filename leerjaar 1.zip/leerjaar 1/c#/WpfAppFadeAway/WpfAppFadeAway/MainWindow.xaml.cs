﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Text.RegularExpressions;
using System.Windows.Shapes;

namespace WpfAppFadeAway
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double _delendoor = 0;
        double _Rest = 0;
        public MainWindow()
        {
            InitializeComponent();

        }

        private void btStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _delendoor = Double.Parse(tbDelendoor.Text);
            }

            catch (Exception) { 
            MessageBoxResult result = MessageBox.Show("Het getal dat je in de texbox hebt ingegeven is geen goede double. wil je een nieuw getal ingeven?", "foutmelding", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Okay,Geef een nieuwe waarde in!");
                    return;
                }
                else
                {
                    this.Close();
                    return;
                }
            }
            _Rest = Double.Parse(tbRest.Text);
            _Rest = _Rest - (_Rest / _delendoor);
            tbRest.Text = _Rest.ToString();
            Image1.Opacity = _Rest;
        }
  

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        _Rest = 1;
        Image1.Opacity = _Rest;
        tbRest.Text = _Rest.ToString();
    }

        private void tbDelendoor_GotFocus(object sender, RoutedEventArgs e)
        {
            tbDelendoor.Text = "";
        }
    }
}

