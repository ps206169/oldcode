﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PO_Grid
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BitmapImage[] _myImages = new BitmapImage[6];
        int counter = 0;
        Button[] _myButtons = new Button[9];
        
        Random _myRandom = new Random();
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                createArrayImages();
                createButtonArray();
            }
            catch { }
        }

        private void createArrayImages()
        {
            _myImages[0] = new BitmapImage(new Uri("Assets/evilwithin1_2.jpg", UriKind.Relative));
            _myImages[1] = new BitmapImage(new Uri("Assets/evilwithin1_1.jpg", UriKind.Relative));
            _myImages[2] = new BitmapImage(new Uri("Assets/evilwithin1_3.jpg", UriKind.Relative));
            _myImages[3] = new BitmapImage(new Uri("Assets/evilwithin1_4.jpg", UriKind.Relative));
            _myImages[4] = new BitmapImage(new Uri("Assets/evilwithin2_1.jpg", UriKind.Relative));
            _myImages[5] = new BitmapImage(new Uri("Assets/evilwithin2_3.jpg", UriKind.Relative));
        }
        
        private void createButtonArray()
        {
            _myButtons[0] = bt1;
            _myButtons[1] = bt2;
            _myButtons[2] = bt3;
            _myButtons[3] = bt4;
            _myButtons[4] = bt5;
            _myButtons[5] = bt6;
            _myButtons[6] = bt7;
            _myButtons[7] = bt8;
            _myButtons[8] = bt9;
        }


        private void btChangeImage(object sender, RoutedEventArgs e)
        {
            imgEvilWithin.Source = _myImages[counter];
            counter++;

            if(counter == 6)
            {
                counter = 0;
            }
        }

       private void btChangeColor(object sender, RoutedEventArgs e)
        {
            for ( int i =0; i < 9; i++) 
            {
                byte red = (byte)_myRandom.Next(0, 255);
                byte green = (byte)_myRandom.Next(0, 255);
                byte blue = (byte)_myRandom.Next(0, 255);
                _myButtons[i].Background = new SolidColorBrush(Color.FromRgb(red,green,blue));
            }
        }
       

    }
}
