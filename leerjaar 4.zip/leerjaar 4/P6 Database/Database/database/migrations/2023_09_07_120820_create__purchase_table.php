<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('purchase', function (Blueprint $table) {
            $table->id();
            $table->foreignID('Boughtby');
            $table->foreignID('OfferID');
            $table->foreignID('StatusID');
            $table->timestamps();

            $table->foreign('Boughtby')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade'); //did we forget the company version? cause they both can sell a procoduct
            $table->foreign('StatusID')->references('id')->on('status')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('OfferID')->references('id')->on('offers')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('purchase');
    }
};
