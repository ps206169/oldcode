<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('productoffer', function (Blueprint $table) {
            $table->id();
            $table->foreignID('ProductID');
            $table->foreignID('OfferID');
            $table->timestamps();

            $table->foreign('ProductID')->references('id')->on('product')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('OfferID')->references('id')->on('offers')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('productoffer');
    }
};
