<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('offers', function (Blueprint $table) {
            $table->id();
            $table->foreignID('StatusID');
            $table->foreignID('GameID');
            $table->foreignID('SoldbyUser')->nullable();
            $table->foreignID('SoldbyCompany')->nullable();
            $table->integer('Price');
            $table->timestamps();

            $table->foreign('StatusID')->references('id')->on('status')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('GameID')->references('id')->on('games')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('SoldbyUser')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('SoldbyCompany')->references('id')->on('company')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('offers');
    }
};
