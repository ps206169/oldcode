<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        DB::table('roles')->insert([
            'Rolename' => 'Helpdesk',
        ]);
        DB::table('roles')->insert([
            'Rolename' => 'Manager',
        ]);
        DB::table('roles')->insert([
            'Rolename' => 'Admin',
        ]);
        DB::table('roles')->insert([
            'Rolename' => 'TroubleShooter',
        ]);
        DB::table('roles')->insert([
            'Rolename' => 'Employee',
        ]);

        DB::table('status')->insert([
            'Statusname' => 'For Sale',
        ]);
        DB::table('status')->insert([
            'Statusname' => 'Bought',
        ]);
        DB::table('status')->insert([
            'Statusname' => 'Pending',
        ]);
        DB::table('status')->insert([
            'Statusname' => 'Failed',
        ]);
        DB::table('status')->insert([
            'Statusname' => 'Succeeded',
        ]);

        DB::table('Games')->insert([
            'Gamename' => 'CS:GO',
            'Description' => 'Shooter game',
            'Imgurl' => 'wkjnbgecynwemnecvwve',
        ]);
        DB::table('Games')->insert([
            'Gamename' => 'Valorant',
            'Description' => 'Shooter game',
            'Imgurl' => 'wkjnbgecynwemnecvwve',
        ]);
        DB::table('Games')->insert([
            'Gamename' => 'Dota 2',
            'Description' => 'moba game',
            'Imgurl' => 'wkjnbgecynwemnecvwve',
        ]);
        DB::table('Games')->insert([
            'Gamename' => 'Team Fortress 2',
            'Description' => 'Shooter game',
            'Imgurl' => 'wkjnbgecynwemnecvwve',
        ]);

    }
}
