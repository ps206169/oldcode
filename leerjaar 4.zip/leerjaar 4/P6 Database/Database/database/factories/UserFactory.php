<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        static $postalID = null;
        if (! $postalID) {
            $postalID = range(1, 101);
            shuffle($postalID);
        }

        return [
            'Username' => $this->faker->username,
            'Useremail' => $this->faker->unique()->safeEmail,
            'Password' => bcrypt('secret'),
            'PostalCodeID' => array_pop($postalID),
        ];
    }
}
