﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Offers.xaml
    /// </summary>
    public partial class Offers : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassOffers> offerDataList = new ObservableCollection<DBclassOffers>();

        public ObservableCollection<DBclassOffers> OfferDataList
        {
            get { return offerDataList; }
            set { offerDataList = value; }
        }

        private DBclassOffers selectedOffer;
        public DBclassOffers SelectedOffer
        {
            get { return selectedOffer; }
            set { selectedOffer = value; OnPropertyChanged(); }
        }

        public Offers()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {


        }
    }
}
