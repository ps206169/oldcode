﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Diagnostics;
using Google.Protobuf.WellKnownTypes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Employees.xaml
    /// </summary>
    public partial class Employees : Page, INotifyPropertyChanged
    {
        private int selectedRoleID;
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassEmployees> employeeDataList = new ObservableCollection<DBclassEmployees>();

        public ObservableCollection<DBclassEmployees> EmployeeDataList
        {
            get { return employeeDataList; }
            set { employeeDataList = value; }
        }

        private DBclassEmployees selectedEmployee;
        public DBclassEmployees SelectedEmployee
        {
            get { return selectedEmployee; }
            set { selectedEmployee = value; OnPropertyChanged(); }
        }


        private ObservableCollection<DBclassRoles> roleDataList = new ObservableCollection<DBclassRoles>();

        public ObservableCollection<DBclassRoles> RoleDataList
        {
            get { return roleDataList; }
            set { roleDataList = value; }
        }

        private DBclassRoles selectedRole;
        public DBclassRoles SelectedRole
        {
            get { return selectedRole; }
            set { selectedRole = value; OnPropertyChanged(); }
        }


        DBclassEmployeeFunctions DB = new DBclassEmployeeFunctions();
        

        public Employees()
        {
            loadEmployeeLst();
            loadRoleLst();
            InitializeComponent();
            DataContext = this;
        }

        public void loadEmployeeLst()
        {
            try
            {
                List<DBclassEmployees> lstemployeeData = DB.GetEmployeeList();

                if (lstemployeeData == null || lstemployeeData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                EmployeeDataList.Clear();

                foreach (DBclassEmployees employeeData in lstemployeeData)
                {
                    EmployeeDataList.Add(employeeData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                EmployeeDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void loadRoleLst()
        {
            try
            {
                List<DBclassRoles> lstRoleData = DB.GetRoleList();

                if (lstRoleData == null || lstRoleData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
               
                RoleDataList.Clear();

                foreach (DBclassRoles roleData in lstRoleData)
                {
                    RoleDataList.Add(roleData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                RoleDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var editedCell = e.EditingElement as FrameworkElement;

                if (editedCell is TextBox textBox)
                {
                    // Handle TextBox columns
                    HandleTextBoxColumn(e, textBox);
                }
            }
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        
        {
            // Get the selected item from the ComboBox
            var comboBox = (ComboBox)sender;
            var selectedRole = (DBclassRoles)comboBox.SelectedItem;

            if (selectedRole != null)
            {
                int employeeID = GetEmployeeIDFromDataGrid(LstEmployee); // Assuming LstEmployee is your DataGrid
                if (employeeID != -1)
                {
                    // Update the role for the employee with the obtained employee ID
                    DB.UpdateRole(employeeID, selectedRole.ID);
                }
                else
                {
                    // Handle the case where no employee is selected
                }
            }
            
            loadEmployeeLst();
            
        }

        private void cbFunction_Loaded(object sender, RoutedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            if(comboBox.Items.Count >= 6)
            {
                //comboBox.Items.Clear();
            }
            
        }


        private int GetEmployeeIDFromDataGrid(DataGrid dataGrid)
        {
            if (dataGrid.SelectedItem != null)
            {
                // Cast the selected item to your DBclassEmployees type
                var selectedEmployee = (DBclassEmployees)dataGrid.SelectedItem;

                if (selectedEmployee != null)
                {
                    // Get the employee ID
                    return selectedEmployee.EmployeeID;
                 
                }
            }

            // Return a default value or handle the case where no employee is selected
            return -1; // You can choose a suitable default value or handle the case differently
        }

        private void HandleTextBoxColumn(DataGridCellEditEndingEventArgs e, TextBox editedCell)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                // Get the edited game from the DataContext
                var editedEmployee = e.Row.DataContext as DBclassEmployees;
                var editedEmployeeID = ((DBclassEmployees)e.Row.Item).ID;
                var editedColumn = e.Column.Header.ToString();

                switch (editedColumn)
                {
                    case "Naam":
                        editedEmployee.Employeename = editedCell.Text;

                        break;
                    case "Email":
                        editedEmployee.EmployeeEmail = editedCell.Text;

                        break;
                    case "Postcode":
                        editedEmployee.PostalCode = editedCell.Text;

                        break;                    
                    case "Huisnummer":
                        editedEmployee.Housenumber = editedCell.Text;

                        break;
 
                    default:
                        MessageBox.Show("Je Hebt niks aangepast.");
                        break;
                }
                // Update the corresponding row in the database
                DB.UpdateEmployee(editedEmployeeID,
                              editedEmployee.Employeename,
                              editedEmployee.EmployeeEmail,
                              editedEmployee.PostalCode,
                              editedEmployee.Housenumber);
            }
            loadEmployeeLst();

        }


        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (!DB.DeleteEmployee((int)selectedEmployee.ID))
            {
                MessageBox.Show("Er is een fout bij het verwijderen");
                return;
            };
            loadEmployeeLst();

        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            EmployeeAddWindow employeeaddpage = new EmployeeAddWindow();
            employeeaddpage.DataSentBack += employeeAddWindow_DataSentBack;
            employeeaddpage.Show();
            
            
        }

        private void employeeAddWindow_DataSentBack(object sender, string data)
        {
            loadEmployeeLst();
        }
    }
}
