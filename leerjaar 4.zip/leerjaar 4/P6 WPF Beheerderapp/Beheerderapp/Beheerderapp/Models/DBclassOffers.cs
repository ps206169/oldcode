﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassOffers
    {
        public int ID { get; set; }
        public int StatusID { get; set; }
        public int GameID { get; set; }
        public int SoldbyUser { get; set; }
        public int SoldbyCompany { get; set; }
        public int Price { get; set; }

        public string Username { get; set; }    
        public string Gamename { get; set; }
        public string Statusname { get; set; }
        public string Companyname { get; set;}




    }
}
