﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassPostalcodes
    {
        public int ID { get; set; }
        public string Housenumber { get; set; }
        public string PostalCode { get; set; }
    }
}
