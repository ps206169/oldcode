﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassCompany : DBclassPostalcodes
    {
        public int ID { get; set; }
        public string Companyname { get; set; }
        public int PostalID { get; set; }
    }
}
