﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassGamesFunctions : Dbclass
    {
        #region Game data call
        public List<DBclassGames> GetGamesList()
        {
            List<DBclassGames> games = new List<DBclassGames>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT g.id, g.Gamename, g.Description, g.Imgurl
                      FROM games g";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassGames game = new DBclassGames();
                    game.ID = (int)row["id"];
                    game.Gamename = (string)row["Gamename"];
                    game.Description = (string)row["Description"];
                    game.Imgurl = (string)row["Imgurl"];
                    games.Add(game);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return games;
        }
        #endregion
        #region Game update call
        public bool UpdateGame(int id, string Gamename, string Description, string Imgurl)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE games g SET g.Gamename = @Gamename, g.Description = @Description, g.Imgurl = @Imgurl WHERE id = @id";

                
                sql.Parameters.AddWithValue("@id", id);
                sql.Parameters.AddWithValue("@Gamename", Gamename);
                sql.Parameters.AddWithValue("@Description", Description);
                sql.Parameters.AddWithValue("@Imgurl", Imgurl);



                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }
        #endregion
        #region Game create call
        public bool AddGame(string gamename, string description, string imgurl)//voeg rollen hieraan toe later.
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    "INSERT INTO `games`(Gamename, Description, Imgurl) VALUES (@Gamename, @Description, @Imgurl)";

                sql.Parameters.AddWithValue("@Gamename", gamename);
                sql.Parameters.AddWithValue("@Description", description);
                sql.Parameters.AddWithValue("@Imgurl", imgurl);



                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
        #region Game delete call
        public bool DeleteGame(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM games WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
