﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassUsersFunctions: Dbclass
    {
        #region User data call
        public List<DBclassUsers> GetUserList()
        {
            List<DBclassUsers> users = new List<DBclassUsers>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT u.id, u.Username, u.Useremail, u.PostalID, p.PostalCode, p.Housenumber, p.id FROM users u JOIN postal_codes p ON p.id = u.PostalID";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassUsers user = new DBclassUsers();
                    user.ID = (int)row["id"];
                    user.Username = (string)row["Username"];
                    user.Useremail = (string)row["Useremail"];
                    user.PostalCode = (string)row["PostalCode"];
                    user.Housenumber = (string)row["Housenumber"];
                    users.Add(user);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return users;
        }
        #endregion
        #region User delete call
        public bool DeleteUser(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    "DELETE FROM users WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
