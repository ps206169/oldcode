﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassProductFunctions: Dbclass
    {
        #region product data call
        public List<DBclassProduct> GetProductList()
        {
            List<DBclassProduct> products = new List<DBclassProduct>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT p.id, p.Productname, p.Description
                      FROM product p";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassProduct product = new DBclassProduct();
                    product.ID = (int)row["id"];
                    product.Productname = (string)row["Productname"];
                    product.Description = (string)row["Description"];
                    products.Add(product);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return products;
        }
        #endregion
        #region Product update call
        public bool UpdateProduct(int id, string Productname, string Description)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE product p SET p.Productname = @Productname, p.Description = @Description "; //pas dit aan

                //Might have to change everything in front of the = signs back to non capitalized letters
                sql.Parameters.AddWithValue("@id", id);
                sql.Parameters.AddWithValue("@Productname", Productname);
                sql.Parameters.AddWithValue("@Description", Description);



                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }
        #endregion
        #region Product create call
        public bool AddProduct(string productName, string description)//voeg rollen hieraan toe later.
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    "INSERT INTO `product`(Productname, Description) VALUES (@Productname, @Description)";

                sql.Parameters.AddWithValue("@Productname", productName);
                sql.Parameters.AddWithValue("@Description", description);



                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
        #region Product delete call
        public bool DeleteProduct(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM product WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
