﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace Beheerderapp.Models
{
    public class Dbclass
    {
        public readonly MySqlConnection conn;

        public Dbclass()
        {
            conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["LootLagoon"].ConnectionString);
        }

        public Dbclass(MySqlConnection connection)
        {
            conn = connection;
        }
    }
}
