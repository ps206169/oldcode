﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassEmployees : DBclassEmployeerole
    {

        public int ID { get; set; }
        public string Employeename { get; set; }
        public string Password { get; set;}
        public string EmployeeEmail { get; set;}
        public int UserID { get; set; }
        public int PostalID { get; set; }
        public DBclassRoles SelectedRole { get; internal set; }
    }
}
