﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassStatus
    {
        public int ID { get; set; }
        public string Statusname { get; set; }
    }
}
