﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassOffersFunctions : Dbclass
    { //edit this later

        #region offer data call
        public List<DBclassOffers> GetOffersList()
        {
            List<DBclassOffers> offers = new List<DBclassOffers>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT o.id, o.GameID, o.StatusID, o.SoldbyUser, o.SoldbyCompany, o.Price, c.id, c.CompanyName, u.id, u.Username, g.id, g.Gamename, s.id, s.Statusname
                      FROM offers o
                      JOIN games g ON g.id = o.GameID
                      JOIN users u ON u.id = o.SoldbyUser
                      JOIN company c ON c.id = o.SoldbyCompany
                      JOIN status s ON s.id = o.StatusID";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassOffers offer = new DBclassOffers();
                    offer.ID = (int)row["id"];
                    offer.GameID = (int)row["GameID"];
                    offer.Gamename = (string)row["Gamename"];
                    offer.StatusID = (int)row["StatusID"];
                    offer.Statusname = (string)row["Statusname"];
                    offer.SoldbyUser = (int)row["SoldbyUser"];
                    offer.Username = (string)row["Username"];
                    offer.SoldbyCompany = (int)row["SoldbyCompany"];
                    offer.Companyname = (string)row["Companyname"];
                    offer.Price = (int)row["Price"];
                    offers.Add(offer);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return offers;
        }
        #endregion
        #region Offer delete call
        public bool DeleteOffer(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM offers WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
