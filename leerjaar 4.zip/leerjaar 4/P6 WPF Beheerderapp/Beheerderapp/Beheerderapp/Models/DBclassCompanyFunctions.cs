﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beheerderapp.Models
{
    public class DBclassCompanyFunctions : Dbclass
    {
        #region Company data call
        public List<DBclassCompany> GetCompanyList()
        {
            List<DBclassCompany> companys = new List<DBclassCompany>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT c.id, c.Companyname, c.PostalID, p.PostalCode, p.Housenumber, p.id FROM company c JOIN postal_codes p ON p.id = c.PostalID";
 
                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassCompany company = new DBclassCompany();
                    company.ID = (int)row["id"];
                    company.Companyname = (string)row["Companyname"];
                    company.PostalCode = (string)row["PostalCode"];
                    company.Housenumber = (string)row["Housenumber"];
                    companys.Add(company);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return companys;
        }
        #endregion
        #region Company delete call
        public bool DeleteCompany(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM company WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
