﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Crypto.Generators;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;

namespace Beheerderapp.Models
{
    public class DBclassEmployeeFunctions : Dbclass
    {
        #region Employee data call
        public List<DBclassEmployees> GetEmployeeList()
        {
            List<DBclassEmployees> employees = new List<DBclassEmployees>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT e.id, e.Employeename, e.EmployeeEmail, e.PostalID, p.PostalCode, p.Housenumber, p.id, er.EmployeeID, er.RoleID, r.id, r.Rolename FROM employees e JOIN postal_codes p ON p.id = e.PostalID JOIN employeerole er ON e.id = er.EmployeeID JOIN roles r ON r.id = er.RoleID;";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassEmployees employee = new DBclassEmployees();
                    employee.ID = (int)row["id"];
                    employee.Employeename = (string)row["Employeename"];
                    employee.EmployeeEmail = (string)row["EmployeeEmail"];
                    employee.PostalCode = (string)row["PostalCode"];
                    employee.Housenumber = (string)row["Housenumber"];
                    employee.Rolename = (string)row["Rolename"];
                    employee.RoleID = Convert.ToInt32(row["RoleID"]);
                    employee.PostalID = Convert.ToInt32(row["PostalID"]);
                    employee.EmployeeID = Convert.ToInt32(row["EmployeeID"]);
                    employees.Add(employee);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return employees;
        }
        #endregion
        #region Employee update call
        public bool UpdateEmployee(int id, string employeeName, string employeeEmail, string postalCode, string houseNumber)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE employees e " +
                                  "SET e.EmployeeEmail = @employeeEmail, e.Employeename = @employeeName WHERE id = @id;" +
                                  "UPDATE postal_codes p " +
                                  "SET p.PostalCode = @postalCode, p.Housenumber = @houseNumber;" +
                                  "WHERE p.id = (SELECT PostalCodeID FROM employees WHERE id = @id);";

                //Might have to change everything in front of the = signs back to non capitalized letters
                sql.Parameters.AddWithValue("@id", id);
                sql.Parameters.AddWithValue("@employeeEmail", employeeEmail);
                sql.Parameters.AddWithValue("@employeeName", employeeName);
                sql.Parameters.AddWithValue("@postalCode", postalCode);
                sql.Parameters.AddWithValue("@houseNumber", houseNumber);

                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }
        #endregion
        #region Employee create call
        public bool AddEmployee(string Employeename, string Password, string EmployeeEmail , string Housenumber, string PostalCode, object selectedItem)//voeg rollen hieraan toe later.
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                  "INSERT INTO postal_codes(PostalCode, Housenumber) VALUES(@PostalCode, @Housenumber);";

                sql.Parameters.AddWithValue("@PostalCode", PostalCode);
                sql.Parameters.AddWithValue("@Housenumber", Housenumber);

                result = sql.ExecuteNonQuery() == 1; // Insert postal code

                sql.CommandText =
                    "INSERT INTO employees(Employeename, EmployeeEmail, Password, PostalID)" +
                    "VALUES(@Employeename, @EmployeeEmail, @Password, LAST_INSERT_ID());";

                sql.Parameters.AddWithValue("@Employeename", Employeename);
                sql.Parameters.AddWithValue("@Password", HashPassword(Password));
                sql.Parameters.AddWithValue("@EmployeeEmail", EmployeeEmail);

                result = sql.ExecuteNonQuery() == 1;

                sql.CommandText =
                    "INSERT INTO employeerole(EmployeeID, RoleID)" +
                    "VALUES(LAST_INSERT_ID(), @RoleID);";

                sql.Parameters.AddWithValue("@RoleID", selectedItem);

                

                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        private string HashPassword(string Password)
        {
            return BCrypt.Net.BCrypt.HashPassword(Password);
        }
        #endregion
        #region Employee delete call
        public bool DeleteEmployee(int id)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    " DELETE FROM employees WHERE  id = @ID";
                sql.Parameters.AddWithValue("@ID", id);

                result = sql.ExecuteNonQuery() == 1;

            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }
        #endregion


        #region Role call
        public List<DBclassRoles> GetRoleList()
        {
            List<DBclassRoles> Roles = new List<DBclassRoles>();
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText =
                    @"SELECT r.id, r.Rolename FROM roles r;";

                MySqlDataReader reader = sql.ExecuteReader();
                DataTable table = new();
                table.Load(reader);
                foreach (DataRow row in table.Rows)
                {


                    DBclassRoles Role = new DBclassRoles();
                    Role.ID = (int)row["id"];
                    Role.Rolename = (string)row["Rolename"];
                    Roles.Add(Role);
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return Roles;
        }
        #endregion
        #region employeerole Update
        public bool UpdateRole(int EmployeeID, int RoleID)
        {
            bool result = false;
            try
            {
                conn.Open();
                MySqlCommand sql = conn.CreateCommand();
                sql.CommandText = "UPDATE employeerole SET RoleID = @RoleID WHERE id = @id";

                //Might have to change everything in front of the = signs back to non capitalized letters
                sql.Parameters.AddWithValue("@id", EmployeeID);
                sql.Parameters.AddWithValue("@RoleID", RoleID);



                result = sql.ExecuteNonQuery() == 1;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message);
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return result;
        }

                    
        #endregion
    }
}
