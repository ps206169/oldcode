﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Beheerderapp.Models;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for GameAddWindow.xaml
    /// </summary>
    public partial class GameAddWindow : Window
    {
        
        public event EventHandler<string> DataSentBack;
        public GameAddWindow()
        {
            InitializeComponent();

        }

        DBclassGamesFunctions DB = new DBclassGamesFunctions();

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            if ((string.IsNullOrEmpty(tbGameName.Text)) 
                || (string.IsNullOrEmpty(tbDescription.Text))
                || (string.IsNullOrEmpty(tbImgurl.Text)))
            {
                MessageBox.Show("Voor gegevens in");
            }
            else
            {
                DB.AddGame(tbGameName.Text, tbDescription.Text, tbImgurl.Text);
                string data = tbGameName.Text;
                DataSentBack?.Invoke(this, data);
                this.Close();
            }


        }

    }
}
