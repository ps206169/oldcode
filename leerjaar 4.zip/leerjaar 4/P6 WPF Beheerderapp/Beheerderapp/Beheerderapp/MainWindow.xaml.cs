﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Markup;
using Beheerderapp.Models;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }


        public void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabControl tabControl = sender as TabControl;
            TabItem selectedTab = tabControl.SelectedItem as TabItem;

            switch (selectedTab.Header.ToString())
            {
                case "Medewerkers":
                    if (Employeeframe.Content == null)
                    {
                        Employeeframe.NavigationService.Navigate(new Employees());
                    }
                    break;

                case "Games":
                    if (Gamesframe.Content == null)
                    {
                        Gamesframe.NavigationService.Navigate(new Games());
                    }
                    break;

                case "Gebruikers":
                    if (Usersframe.Content == null)
                    {
                        Usersframe.NavigationService.Navigate(new Users());
                    }
                    break;

                case "Bedrijven":
                    if (Companyframe.Content == null)
                    {
                        Companyframe.NavigationService.Navigate(new Companies());
                    }
                    break;

                case "Aanbod":
                    if (Offersframe.Content == null)
                    {
                        Offersframe.NavigationService.Navigate(new Offers());
                    }
                    break;

                case "Products":
                    if (Productframe.Content == null)
                    {
                        Productframe.NavigationService.Navigate(new Products());
                    }
                    break;


                // Add more cases as needed for other tab headers

                default:
                    if (Dashboardframe.Content == null)
                    {
                        Dashboardframe.NavigationService.Navigate(new Dashboard());
                    }
                    break;
            }
        }
    }
}
