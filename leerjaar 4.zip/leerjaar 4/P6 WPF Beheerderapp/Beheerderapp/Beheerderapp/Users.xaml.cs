﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Users.xaml
    /// </summary>
    public partial class Users : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassUsers> usersDataList = new ObservableCollection<DBclassUsers>();

        public ObservableCollection<DBclassUsers> UsersDataList
        {
            get { return usersDataList; }
            set { usersDataList = value; }
        }

        private DBclassUsers selectedUser;
        public DBclassUsers SelectedUser
        {
            get { return selectedUser; }
            set { selectedUser = value; OnPropertyChanged(); }
        }


        DBclassUsersFunctions DB = new DBclassUsersFunctions();

        public Users()
        {
            loadUserLst();
            InitializeComponent();
            DataContext = this;
        }

        public void loadUserLst()
        {
            try
            {
                List<DBclassUsers> lstuserData = DB.GetUserList();

                if (lstuserData == null || lstuserData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                UsersDataList.Clear();

                foreach (DBclassUsers userData in lstuserData)
                {
                    UsersDataList.Add(userData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UsersDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("wilt u dit verwijderen?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (SelectedUser != null && DB != null)
                {
                    if (!DB.DeleteUser((int)SelectedUser.ID))
                    {
                        MessageBox.Show("Er is een fout bij het verwijderen");
                        return;
                    };
                    loadUserLst();
                }
                else
                {
                    MessageBox.Show("SelectedUser or DB is null. Cannot proceed with the deletion.");
                }
              
            }
            else
            {

            }


        }
    }
}
