﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Products.xaml
    /// </summary>
    public partial class Products : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassProduct> productDataList = new ObservableCollection<DBclassProduct>();

        public ObservableCollection<DBclassProduct> ProductDataList
        {
            get { return productDataList; }
            set { productDataList = value; }
        }

        private DBclassProduct selectedProduct;
        public DBclassProduct SelectedProduct
        {
            get { return selectedProduct; }
            set { selectedProduct = value; OnPropertyChanged(); }
        }

        DBclassProductFunctions DB = new DBclassProductFunctions();

        public Products()
        {
            InitializeComponent();
            loadProductLst();
            DataContext = this;  
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Do you want to continue?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (!DB.DeleteProduct((int)SelectedProduct.ID))
                {
                    MessageBox.Show("Er is een fout bij het verwijderen");
                    return;
                };
                loadProductLst();
            }
            else
            {
                // User clicked "No," put your code here.
            }

        }

        public void loadProductLst()
        {
            try
            {
                List<DBclassProduct> lstProductData = DB.GetProductList();

                if (lstProductData == null || lstProductData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                ProductDataList.Clear();

                foreach (DBclassProduct productData in lstProductData)
                {
                    ProductDataList.Add(productData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                ProductDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            ProductAddWindow productaddpage = new ProductAddWindow();
            productaddpage.DataSentBack += ProductAddWindow_DataSentBack;
            productaddpage.Show();


        }

        private void ProductAddWindow_DataSentBack(object sender, string data)
        {
            loadProductLst();
        }
    }
}
