﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for ProductAddWindow.xaml
    /// </summary>
    public partial class ProductAddWindow : Window
    {

        public event EventHandler<string> DataSentBack;
        public ProductAddWindow()
        {
            InitializeComponent();
        }

        DBclassProductFunctions DB = new DBclassProductFunctions();

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            if ((string.IsNullOrEmpty(tbProductName.Text))
                || (string.IsNullOrEmpty(tbDescription.Text)))
            {
                MessageBox.Show("Voor gegevens in");
            }
            else
            {
                DB.AddProduct(tbProductName.Text, tbDescription.Text);
                string data = tbProductName.Text;
                DataSentBack?.Invoke(this, data);
                this.Close();
            }


        }
    }
}
