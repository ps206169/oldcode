﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Beheerderapp.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Companies.xaml
    /// </summary>
    public partial class Companies : Page , INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassCompany> companyDataList = new ObservableCollection<DBclassCompany>();

        public ObservableCollection<DBclassCompany> CompanyDataList
        {
            get { return companyDataList; }
            set { companyDataList = value; }
        }

        private DBclassCompany selectedCompany;
        public DBclassCompany SelectedCompany
        {
            get { return selectedCompany; }
            set { selectedCompany = value; OnPropertyChanged(); }
        }

        DBclassCompanyFunctions DB = new DBclassCompanyFunctions();


        public Companies()
        {
            InitializeComponent();
            loadCompanyLst();
            DataContext = this;
        }

        public void loadCompanyLst()
        {
            try
            {
                List<DBclassCompany> lstCompanyData = DB.GetCompanyList();

                if (lstCompanyData == null || lstCompanyData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                CompanyDataList.Clear();

                foreach (DBclassCompany companyData in lstCompanyData)
                {
                    CompanyDataList.Add(companyData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                CompanyDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Do you want to continue?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (!DB.DeleteCompany((int)selectedCompany.ID))
                {
                    MessageBox.Show("Er is een fout bij het verwijderen");
                    return;
                };
                loadCompanyLst();
            }
            else
            {
                // User clicked "No," put your code here.
            }


        }
    }
}
