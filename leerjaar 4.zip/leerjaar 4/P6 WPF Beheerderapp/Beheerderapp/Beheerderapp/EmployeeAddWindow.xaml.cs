﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for EmployeeAddWindow.xaml
    /// </summary>
    public partial class EmployeeAddWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassRoles> roleDataList = new ObservableCollection<DBclassRoles>();

        public ObservableCollection<DBclassRoles> RoleDataList
        {
            get { return roleDataList; }
            set { roleDataList = value; }
        }

        private DBclassRoles selectedRole;
        public DBclassRoles SelectedRole
        {
            get { return selectedRole; }
            set { selectedRole = value; OnPropertyChanged(); }
        }


        private int _selectedRoleID;

        public int SelectedRoleID
        {
            get { return _selectedRoleID; }
            set
            {
                _selectedRoleID = value;
                OnPropertyChanged();
            }
        }

        public event EventHandler<string> DataSentBack;
        DBclassEmployeeFunctions DB = new DBclassEmployeeFunctions();

        public EmployeeAddWindow()
        {
            loadRoleLst();
            InitializeComponent();
            DataContext = this;
        }

        public void loadRoleLst()
        {
            try
            {
                List<DBclassRoles> lstRoleData = DB.GetRoleList();

                if (lstRoleData == null || lstRoleData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                RoleDataList.Clear();

                foreach (DBclassRoles roleData in lstRoleData)
                {
                    RoleDataList.Add(roleData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                RoleDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Add_Click(object sender, RoutedEventArgs e)
        {

            //if ((string.IsNullOrEmpty(tbName.Text))
            //    || (string.IsNullOrEmpty(tbDescription.Text))
            //    || (string.IsNullOrEmpty(tbImgurl.Text)))
            //{
            //    MessageBox.Show("Voor gegevens in");
            //}
            //else
            //{
                DB.AddEmployee(tbName.Text, tbPassword.Text, tbEmail.Text, tbHousenumber.Text, tbPostalCode.Text, cbRoles.SelectedValue);
                string data = tbName.Text;
                DataSentBack?.Invoke(this, data);
                this.Close();
            //}


        }
    }
}
