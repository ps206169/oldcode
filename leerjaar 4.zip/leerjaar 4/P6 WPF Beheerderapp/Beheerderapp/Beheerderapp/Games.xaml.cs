﻿using Beheerderapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Diagnostics;


namespace Beheerderapp
{
    /// <summary>
    /// Interaction logic for Games.xaml
    /// </summary>
    public partial class Games : Page,  INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private ObservableCollection<DBclassGames> gameDataList = new ObservableCollection<DBclassGames>();

        public ObservableCollection<DBclassGames> GameDataList
        {
            get { return gameDataList; }
            set { gameDataList = value; }
        }

        private DBclassGames selectedGame;
        public DBclassGames SelectedGame
        {
            get { return selectedGame; }
            set { selectedGame = value; OnPropertyChanged(); }
        }

        DBclassGamesFunctions DB = new DBclassGamesFunctions();

        public Games()
        {
            loadGameLst();
            InitializeComponent();
            DataContext = this;
        }

        public void loadGameLst()
        {
            try
            {
                List<DBclassGames> lstGameData = DB.GetGamesList();

                if (lstGameData == null || lstGameData.Count == 0)
                {
                    MessageBox.Show("Geen data gevonden.", "", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                GameDataList.Clear();

                foreach (DBclassGames gameData in lstGameData)
                {
                    GameDataList.Add(gameData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                GameDataList.Clear();
                MessageBox.Show("Er is een fout opgetreden tijdens het ophalen van de data.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("wilt u dit verwijderen?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (!DB.DeleteGame((int)selectedGame.ID))
                {
                    MessageBox.Show("Er is een fout bij het verwijderen");
                    return;
                };
                loadGameLst();
            }
            else
            {
               
            }


        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            GameAddWindow gameaddpage = new GameAddWindow();
            gameaddpage.DataSentBack += GameAddWindow_DataSentBack;
            gameaddpage.Show();


        }

        private void OnCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                // Krijg de informatie van de datagrid cell
                var editedCell = e.EditingElement as TextBox;
                var editedContent = editedCell.Text;

                // krijg de overig informatie van de cell
                var editedGame = e.Row.DataContext as DBclassGames;

                // je krijgt het ID van je rij, ivm dat je de ID niet aanpast 
                var editedGameID = ((DBclassGames)e.Row.Item).ID;

                var editedColumn = e.Column.Header.ToString();
                //allemaal tijdelijk zodat ik kan zien of de informatie wordt opgeslagen
                switch (editedColumn)
                {
                    case "Naam":
                        editedGame.Gamename = editedContent;

                        break;
                    case "Beschrijving":
                        editedGame.Description = editedContent;

                        break;
                    case "Image":
                        editedGame.Imgurl = editedContent;

                        break;
                    default:
                        MessageBox.Show("Je Hebt niks aangepast.");
                        break;
                }
                // Update the corresponding row in the database
                DB.UpdateGame(editedGameID,
                              editedGame.Gamename,
                              editedGame.Description,
                              editedGame.Imgurl);
            }

        }

        private void GameAddWindow_DataSentBack(object sender, string data)
        {
            loadGameLst();
        }
    }
}
