<?php $__currentLoopData = $oefeningen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oefening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\rexbo\Documents\school\leerjaar 2\Project5\Laravel-P5\Front-end\resources\views/page.blade.php ENDPATH**/ ?>