<?php $__currentLoopData = $prestaties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestatie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($prestatie->id); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\rexbo\Documents\school\leerjaar 2\Project5\Laravel-P5\Front-end\resources\views/Page.blade.php ENDPATH**/ ?>