@foreach($oefeningen as $oefening)

@endforeach
